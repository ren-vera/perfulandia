package com.perfulandia.boletaservice.model;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
@Schema(description = "Clase que representa una boleta con sus propiedades")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Boleta {
    @Schema(description = "Id o campo unico para la boleta", example = "1")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Schema(description = "nombre que representa al cliente")
    private String nombreUsuario;

    @Schema(description = "correo del cliente")
    private String correoUsuario;

    @Schema(description = "nombre que recibe el producto")
    private String nombreProducto;

    @Schema(description = "precio que recibe el producto")
    private Double precioProducto;

    @Schema(description = "fecha que recibe la boleta")
    private LocalDate fechaEmision;
}
