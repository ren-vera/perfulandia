package com.perfulandia.boletaservice.config;

import io.swagger.v3.oas.models.*;
        import io.swagger.v3.oas.models.info.*;
        import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API De perfulandia 'boleta'")
                        .version("1.0.0")
                        .description("documentación de la API del microservicio 'boleta'")
                        .contact(new Contact()
                                .name("Renato Vera")
                                .email("ren.vera@duocuc.cl")
                                .url("https://github.com/Antonellacuvertino/perfulandia")
                        )
                );
    }

}
