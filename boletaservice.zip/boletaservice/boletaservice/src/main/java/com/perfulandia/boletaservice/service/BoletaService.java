package com.perfulandia.boletaservice.service;

import com.perfulandia.boletaservice.dto.EmitirBoletaRequest;
import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.repository.BoletaRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class BoletaService {

    private final BoletaRepository boletaRepository;

    public BoletaService(BoletaRepository boletaRepository) {
        this.boletaRepository = boletaRepository;
    }

    public List<Boleta> listar() {
        return boletaRepository.findAll();
    }

    // Ahora recibe todo el DTO para crear la boleta con datos completos
    public Boleta emitirBoleta(EmitirBoletaRequest request) {
        Boleta nueva = Boleta.builder()
                .nombreUsuario(request.getNombreUsuario())
                .correoUsuario(request.getCorreoUsuario())
                .nombreProducto(request.getNombreProducto())
                .precioProducto(request.getPrecioProducto())
                .fechaEmision(LocalDate.now()) // Fecha actual, o puede venir en DTO si prefieres
                .build();
        return boletaRepository.save(nueva);
    }
}
