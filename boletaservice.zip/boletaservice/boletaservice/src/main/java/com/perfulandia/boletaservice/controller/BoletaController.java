package com.perfulandia.boletaservice.controller;

import com.perfulandia.boletaservice.dto.EmitirBoletaRequest;
import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.service.BoletaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

        import java.util.List;

@Tag(name = "Boleta Controlador", description = "Operaciones del CRUD para los endpoint de boleta")
@RestController
@RequestMapping("/api/boletas")
public class BoletaController {

    private final BoletaService service;

    public BoletaController(BoletaService service) {
        this.service = service;
    }

    @Operation(summary = "Obtiene las boletas", description = "Devuelve una lista con las boletas guardadas en la base de datos")
    @ApiResponse(responseCode = "200", description = "Consulta a las boletas exitosa")
    @GetMapping
    public List<Boleta> listar() {
        return service.listar();
    }

    @Operation(summary = "Crea una boleta", description = "Devuelve un JSON con la boleta agregada")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Boleta agregada exitosamente"),
            @ApiResponse(responseCode = "400", description = "Error en la validación")
    })
    @PostMapping("/emitir")
    public Boleta emitir(@Valid @RequestBody EmitirBoletaRequest request) {
        return service.emitirBoleta(request);
    }
}
