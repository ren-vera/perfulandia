package com.perfulandia.boletaservice.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EmitirBoletaRequest {

        @Schema(description = "ID del usuario que emite la boleta", example = "1", required = true)
        @NotNull
        private Long usuarioId;

        @Schema(description = "ID del producto incluido en la boleta", example = "1", required = true)
        @NotNull
        private Long productoId;

        @Schema(description = "Nombre del usuario", example = "Renato")
        private String nombreUsuario;

        @Schema(description = "Correo del usuario", example = "renato@correo.com")
        private String correoUsuario;

        @Schema(description = "Nombre del producto", example = "Strong with you 100ml")
        private String nombreProducto;

        @Schema(description = "Precio del producto", example = "120000")
        private double precioProducto;
}


