package com.perfulandia.boletaservice.controllerTest;

import com.perfulandia.boletaservice.controller.BoletaController;
import com.perfulandia.boletaservice.dto.EmitirBoletaRequest;
import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.service.BoletaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BoletaController.class)
public class BoletaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private BoletaService service;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    @DisplayName("TESTING 1 - GET /api/boletas")
    void testGetAll() throws Exception {
        Boleta boleta = new Boleta(
                1L,
                "Renato",
                "ren.vera@duocuc.cl",
                "Strong with you 100ml",
                120.000,
                LocalDate.of(2025, 6, 27)
        );

        when(service.listar()).thenReturn(List.of(boleta));

        mockMvc.perform(get("/api/boletas"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombreUsuario").value("Renato"))
                .andExpect(jsonPath("$[0].nombreProducto").value("Strong with you 100ml"));
    }

    //#############################################################################################################
    @Test
    @DisplayName("TESTING 2 - POST /api/boletas/emitir")
    void testEmitirBoleta() throws Exception {
        // Crear el objeto Boleta que esperas como respuesta
        Boleta boleta = Boleta.builder()
                .id(1L)
                .nombreUsuario("Renato")
                .correoUsuario("ren.vera@gmail.cl")
                .nombreProducto("Strong with you 100ml")
                .precioProducto(120.000)
                .fechaEmision(LocalDate.of(2025, 7, 2))
                .build();

        // Crear el objeto DTO que se enviará en la petición y se usará para simular la respuesta
        EmitirBoletaRequest request = new EmitirBoletaRequest();
        request.setUsuarioId(1L);
        request.setProductoId(1L);
        // Inicializa otros campos si los usas en el método emitirBoleta

        // Simular el comportamiento del servicio con Mockito usando el DTO
        when(service.emitirBoleta(request)).thenReturn(boleta);

        // JSON que enviarás en la petición POST
        String jsonRequest = """
                {
                  "usuarioId": 1,
                  "productoId": 1
                }
                """;

        mockMvc.perform(post("/api/boletas/emitir")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreUsuario").value("Renato"))
                .andExpect(jsonPath("$.nombreProducto").value("Strong with you 100ml"));
    }
}