
package com.perfulandia.boletaservice.serviceTest;

import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.repository.BoletaRepository;
import com.perfulandia.boletaservice.service.BoletaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class BoletaServiceTest {

    @InjectMocks
    private BoletaService service;

    @Mock
    private BoletaRepository repo;

    @BeforeEach
    void setUp() {
        // Inicializa los mocks antes de cada test
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Testing 1 al servicio del método listar()")
    void testFindAll() {
        // Simular que repo.findAll() devuelve una lista con una boleta
        when(repo.findAll()).thenReturn(
                List.of(new Boleta(1L,"Renato","ren.vera@duocuc.cl","Strong with you 100ml",120.000, LocalDate.of(2025,6,27)))
        );

        // Ejecutar método del servicio a probar
        List<Boleta> resultado = service.listar();

        // Verificar que la lista devuelta tenga tamaño 1
        assertEquals(1, resultado.size());

        // Opcional: verificar algunos campos específicos
        assertEquals("Renato", resultado.get(0).getNombreUsuario());
        assertEquals("Strong with you 100ml", resultado.get(0).getNombreProducto());
    }
}
